#!/usr/bin/env python3
"""
PRD 完整性验证脚本

用于验证生成的测试导向 PRD 是否符合规范要求。
检查项包括：
- 必需章节是否完整
- 编号格式是否正确
- 场景覆盖统计是否输出
- 待确认项是否有编号

使用方法：
    python validate_prd.py <prd_file_path>

示例：
    python validate_prd.py "D:/workplace/Finenter-Test/Prd/订单管理_测试导向PRD.md"
"""

import re
import sys
from pathlib import Path
from typing import List, Tuple


class PRDValidator:
    """PRD 文档验证器"""

    # 必需章节列表
    REQUIRED_SECTIONS = [
        "文档元信息",
        "文档目标",
        "范围定义",
        "功能拆解",
        "状态模型与状态迁移",
        "业务规则矩阵",
        "异常与边界场景",
        "功能交互矩阵",
        "测试场景挖掘清单",
        "测试拆解建议",
        "待确认项",
    ]

    # 编号规则检查
    ID_PATTERNS = {
        "BR": r"BR-\d{3}",  # 业务规则
        "EX": r"EX-\d{3}",  # 异常场景
        "OQ": r"OQ-\d{3}",  # 待确认项
        "INT": r"INT-\d{3}",  # 交互场景
        "TC": r"TC\d{3}",  # 测试用例
    }

    # 场景清单检查项
    SCENARIO_CHECKLIST = [
        "功能正向场景",
        "输入验证场景",
        "业务规则场景",
        "状态流转场景",
        "异常与容错场景",
        "会话安全场景",
        "兼容性场景",
        "性能与极限场景",
    ]

    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        self.content = ""
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.infos: List[str] = []

    def load_file(self) -> bool:
        """加载 PRD 文件"""
        if not self.file_path.exists():
            self.errors.append(f"文件不存在: {self.file_path}")
            return False

        try:
            self.content = self.file_path.read_text(encoding="utf-8")
            return True
        except Exception as e:
            self.errors.append(f"读取文件失败: {e}")
            return False

    def check_required_sections(self) -> None:
        """检查必需章节"""
        for section in self.REQUIRED_SECTIONS:
            pattern = rf"###?\s*\d*\.?\s*{section}"
            if not re.search(pattern, self.content):
                self.errors.append(f"缺少必需章节: {section}")

    def check_id_format(self) -> None:
        """检查编号格式"""
        for id_type, pattern in self.ID_PATTERNS.items():
            matches = re.findall(pattern, self.content)
            if matches:
                self.infos.append(f"{id_type} 编号使用正确: {len(matches)} 个")
            else:
                # OQ 可能为空，其他应该有
                if id_type in ["BR", "EX"]:
                    self.warnings.append(f"未发现 {id_type}-xxx 格式编号")

    def check_scenario_coverage(self) -> None:
        """检查场景覆盖统计"""
        if "场景覆盖统计" not in self.content:
            self.errors.append("缺少场景覆盖统计")
            return

        # 检查是否包含所有场景类别
        for scenario in self.SCENARIO_CHECKLIST:
            if scenario not in self.content:
                self.warnings.append(f"场景覆盖统计可能不完整，缺少: {scenario}")

    def check_oq_items(self) -> None:
        """检查待确认项"""
        oq_pattern = r"OQ-\d{3}"
        oq_matches = re.findall(oq_pattern, self.content)

        if oq_matches:
            self.infos.append(f"待确认项数量: {len(set(oq_matches))} 个")
        else:
            self.infos.append("未发现待确认项（可能需求完整，无需确认）")

    def check_functional_interaction(self) -> None:
        """检查功能交互矩阵完整性"""
        required_dimensions = [
            "用户操作链路",
            "数据流向分析",
            "系统联动场景",
            "并发与冲突场景",
        ]

        for dim in required_dimensions:
            if dim not in self.content:
                self.warnings.append(f"功能交互矩阵可能不完整，缺少: {dim}")

    def check_delivery_requirements(self) -> None:
        """检查交付要求"""
        # 检查是否有统计输出标记
        if "总计:" not in self.content and "X/35" not in self.content:
            self.warnings.append("场景覆盖统计格式可能不正确，应包含 '总计: X/35'")

    def validate(self) -> Tuple[bool, List[str], List[str], List[str]]:
        """执行完整验证"""
        if not self.load_file():
            return False, self.errors, self.warnings, self.infos

        self.check_required_sections()
        self.check_id_format()
        self.check_scenario_coverage()
        self.check_oq_items()
        self.check_functional_interaction()
        self.check_delivery_requirements()

        is_valid = len(self.errors) == 0
        return is_valid, self.errors, self.warnings, self.infos


def print_results(
    validator: PRDValidator, is_valid: bool, errors: List[str], warnings: List[str], infos: List[str]
) -> None:
    """打印验证结果"""
    print(f"\n{'='*60}")
    print(f"验证文件: {validator.file_path}")
    print(f"{'='*60}")

    # 错误
    if errors:
        print(f"\n❌ 错误 ({len(errors)} 项):")
        for error in errors:
            print(f"   - {error}")
    else:
        print("\n✅ 未发现错误")

    # 警告
    if warnings:
        print(f"\n⚠️ 警告 ({len(warnings)} 项):")
        for warning in warnings:
            print(f"   - {warning}")

    # 信息
    if infos:
        print(f"\nℹ️ 信息 ({len(infos)} 项):")
        for info in infos:
            print(f"   - {info}")

    # 总结
    print(f"\n{'='*60}")
    if is_valid:
        print("✅ 验证通过！PRD 符合规范要求。")
    else:
        print("❌ 验证失败！请修复上述错误。")
    print(f"{'='*60}\n")


def main() -> int:
    """主入口"""
    if len(sys.argv) < 2:
        print("用法: python validate_prd.py <prd_file_path>")
        print("\n示例:")
        print('  python validate_prd.py "订单管理_测试导向PRD.md"')
        return 1

    file_path = sys.argv[1]
    validator = PRDValidator(file_path)
    is_valid, errors, warnings, infos = validator.validate()

    print_results(validator, is_valid, errors, warnings, infos)

    return 0 if is_valid else 1


if __name__ == "__main__":
    sys.exit(main())
